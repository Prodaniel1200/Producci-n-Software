# 🗄️ Integración MongoDB – Agenda CONIITI

## Qué se cambió

| Archivo | Acción |
|---|---|
| `docker-compose.yml` | Se agregó el servicio `mongo` (MongoDB 7.0) con volumen persistente y healthcheck |
| `mongo-init/01_seed_ponentes.js` | Script de seed: inserta los 7 ponentes con todos sus campos en `coniiti_db.ponentes` |
| `services/agenda_service/app/service.py` | Reemplaza la lista estática `PONENTES` por queries reales a MongoDB con `pymongo` |
| `services/agenda_service/app/config.py` | Agrega `MONGO_URI` y `MONGO_DB` como variables de entorno |
| `services/agenda_service/app/routes.py` | Agrega endpoint `GET /api/ponentes/<id>` para leer un ponente completo |
| `services/agenda_service/requirements.txt` | Agrega `pymongo==4.7.3` |

---

## Estructura del documento en MongoDB

```json
{
  "_id": "ObjectId generado automáticamente",
  "nombre": "Dra. Martinez",
  "pais": "Mexico",
  "bandera": "banderas/mexico.png",        // ruta relativa para url_for('static',...)
  "bandera_url": "https://flagcdn.com/w40/mx.png",  // URL directa para recuadros futuros
  "foto": null,                             // URL/ruta a foto del ponente
  "descripcion": "Especialista en...",      // Bio completa
  "titulo_ponencia": "Innovación tecnológica en la era de la IA",
  "tipo": "Conferencia",
  "fecha": "2026-05-10",
  "hora": "09:00",
  "modalidad": "Presencial",
  "sede": "Claustro",
  "salon": "Auditorio 1",
  "activo": true,
  "creado_en": "2026-05-18T..."
}
```

---

## Cómo aplicar los cambios

### 1. Copiar archivos al repo

```bash
# Desde la raíz de Docker-Microservices/
cp /ruta/de/descarga/docker-compose.yml .
cp /ruta/de/descarga/agenda_service/app/service.py  services/agenda_service/app/service.py
cp /ruta/de/descarga/agenda_service/app/config.py   services/agenda_service/app/config.py
cp /ruta/de/descarga/agenda_service/app/routes.py   services/agenda_service/app/routes.py
cp /ruta/de/descarga/agenda_service/requirements.txt services/agenda_service/requirements.txt
mkdir -p mongo-init
cp /ruta/de/descarga/mongo-init/01_seed_ponentes.js mongo-init/
```

### 2. Levantar con Docker Compose

```bash
docker compose down -v        # limpiar estado anterior (borra el volumen de mongo)
docker compose up --build
```

El seed corre automáticamente la primera vez que el contenedor de Mongo arranca.  
Si el volumen ya existe, el seed **no** vuelve a correr (comportamiento estándar de MongoDB).

Para forzar un re-seed:
```bash
docker compose down -v        # -v elimina el volumen mongo-data
docker compose up --build
```

---

## APIs nuevas / actualizadas

### `GET /api/agenda?page=1&per_page=5`
Igual que antes, pero ahora los datos vienen de MongoDB.

Cada ponente en la respuesta ahora incluye campos extra:
```json
{
  "id": "664abc...",
  "nombre": "Dra. Martinez",
  "pais": "Mexico",
  "bandera": "banderas/mexico.png",
  "bandera_url": "https://flagcdn.com/w40/mx.png",
  "foto": null,
  "descripcion": "Especialista en..."
}
```

### `GET /api/ponentes/<id>`  ← **NUEVO**
Devuelve el documento completo de un ponente por su `_id` de MongoDB.

### `POST /api/ponentes`
El payload ahora acepta los campos nuevos: `descripcion`, `bandera_url`, `foto`, `titulo_ponencia`.  
El campo `bandera` y `bandera_url` se infieren automáticamente a partir del `pais` si no se envían.

---

## Próximos pasos (cuando hagas los recuadros)

En el template `agenda.html`, donde dice:

```html
<img src="{{ url_for('static', filename=evento.ponente.bandera) }}" ...>
```

Podrás cambiarlo por un recuadro que use `evento.ponente.bandera_url` (URL directa del CDN)
o hacer una llamada a `GET /api/ponentes/<evento.ponente.id>` para traer toda la info del ponente
(foto, descripción, etc.) y renderizarla en un card completo.
