"""
agenda_service/app/service.py
==============================
Lógica de negocio de la agenda.
Los datos de ponentes se leen desde MongoDB (coniiti_db.ponentes)
en lugar de la lista estática anterior.
"""

import math
from copy import deepcopy
from typing import Any, Callable

from pymongo import MongoClient
from bson import ObjectId
import os

# ──────────────────────────────────────────────
# Conexión a MongoDB
# ──────────────────────────────────────────────

_MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017/coniiti_db")
_DB_NAME = os.getenv("MONGO_DB", "coniiti_db")

def _get_collection():
    """Devuelve la colección de ponentes. Crea el cliente en cada llamada
    para evitar problemas de fork en Gunicorn multi-worker."""
    client = MongoClient(_MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client[_DB_NAME]
    return db["ponentes"]


def _serialize(doc: dict) -> dict:
    """Convierte ObjectId a string para que sea JSON-serializable."""
    doc = dict(doc)
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    if "creado_en" in doc:
        doc["creado_en"] = doc["creado_en"].isoformat() if doc["creado_en"] else None
    return doc


# ──────────────────────────────────────────────
# Helpers internos
# ──────────────────────────────────────────────

def _build_event(ponente: dict[str, Any]) -> dict:
    return {
        "fecha": ponente.get("fecha", ""),
        "hora": ponente.get("hora", ""),
        "tipo": ponente.get("tipo", "Ponencia"),
        "titulo": ponente.get("titulo_ponencia", ponente.get("titulo", "")),
        "ponente": {
            "nombre": ponente.get("nombre", ""),
            "pais": ponente.get("pais", ""),
            # bandera: ruta relativa usada en url_for('static', filename=...)
            "bandera": ponente.get("bandera", ""),
            # bandera_url: URL directa (CDN de banderas), disponible para futuros recuadros
            "bandera_url": ponente.get("bandera_url", ""),
            # foto: URL/ruta de la foto del ponente
            "foto": ponente.get("foto"),
            # descripcion: bio / descripción completa del ponente
            "descripcion": ponente.get("descripcion", ""),
            # _id de MongoDB para enlazar con otros servicios
            "id": ponente.get("_id", ""),
        },
        "modalidad": ponente.get("modalidad", "Presencial"),
        "sede": ponente.get("sede", ""),
        "salon": ponente.get("salon", ""),
    }


# ──────────────────────────────────────────────
# API pública
# ──────────────────────────────────────────────

def get_agenda(page: int = 1, per_page: int = 5) -> dict:
    """
    Devuelve la página de eventos y ponentes leídos desde MongoDB.
    """
    col = _get_collection()

    total = col.count_documents({"activo": True})
    total_pages = max(1, math.ceil(total / per_page))
    safe_page = min(max(page, 1), total_pages)
    skip = (safe_page - 1) * per_page

    cursor = (
        col.find({"activo": True})
           .sort([("fecha", 1), ("hora", 1)])
           .skip(skip)
           .limit(per_page)
    )

    ponentes_raw = [_serialize(doc) for doc in cursor]

    eventos = [_build_event(p) for p in ponentes_raw]

    ponentes_ui = [
        {
            "id":          p.get("_id", ""),
            "nombre":      p.get("nombre", ""),
            "pais":        p.get("pais", ""),
            "bandera":     p.get("bandera", ""),
            "bandera_url": p.get("bandera_url", ""),
            "foto":        p.get("foto"),
            "descripcion": p.get("descripcion", ""),
        }
        for p in ponentes_raw
    ]

    return {
        "page":        safe_page,
        "per_page":    per_page,
        "total":       total,
        "total_pages": total_pages,
        "ponentes":    ponentes_ui,
        "eventos":     eventos,
    }


def get_ponente_by_id(ponente_id: str) -> dict | None:
    """Devuelve un ponente completo por su _id de MongoDB."""
    col = _get_collection()
    try:
        doc = col.find_one({"_id": ObjectId(ponente_id)})
    except Exception:
        return None
    return _serialize(doc) if doc else None


def validate_ponencia_payload(payload: dict[str, Any]) -> dict:
    required = ["nombre", "pais", "titulo_ponencia", "fecha", "hora"]
    missing = [f for f in required if not str(payload.get(f, "")).strip()]
    if missing:
        return {"ok": False, "error": f"Campos obligatorios faltantes: {', '.join(missing)}"}
    return {"ok": True}


def create_ponencia(
    payload: dict[str, Any],
    notifier: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
) -> dict:
    """
    Inserta un nuevo ponente en MongoDB y opcionalmente notifica.
    """
    validation = validate_ponencia_payload(payload)
    if not validation["ok"]:
        return validation

    # Inferir ruta de bandera a partir del país si no se envía
    pais_lower = payload["pais"].strip().lower()
    pais_bandera_map = {
        "mexico":    ("banderas/mexico.png",    "https://flagcdn.com/w40/mx.png"),
        "colombia":  ("banderas/colombia.png",  "https://flagcdn.com/w40/co.png"),
        "argentina": ("banderas/argentina.png", "https://flagcdn.com/w40/ar.png"),
        "alemania":  ("banderas/alemania.png",  "https://flagcdn.com/w40/de.png"),
        "francia":   ("banderas/francia.png",   "https://flagcdn.com/w40/fr.png"),
        "brasil":    ("banderas/brasil.png",     "https://flagcdn.com/w40/br.png"),
        "panama":    ("banderas/panama.png",    "https://flagcdn.com/w40/pa.png"),
    }
    bandera_local, bandera_url = pais_bandera_map.get(
        pais_lower, ("banderas/colombia.png", "https://flagcdn.com/w40/co.png")
    )

    ponencia = {
        "nombre":          payload["nombre"].strip(),
        "pais":            payload["pais"].strip(),
        "bandera":         payload.get("bandera", bandera_local) or bandera_local,
        "bandera_url":     payload.get("bandera_url", bandera_url) or bandera_url,
        "foto":            payload.get("foto"),
        "descripcion":     payload.get("descripcion", "").strip(),
        "titulo_ponencia": payload["titulo_ponencia"].strip(),
        "tipo":            payload.get("tipo", "Ponencia").strip() or "Ponencia",
        "fecha":           payload["fecha"].strip(),
        "hora":            payload["hora"].strip(),
        "modalidad":       payload.get("modalidad", "Presencial").strip() or "Presencial",
        "sede":            payload.get("sede", "Claustro").strip() or "Claustro",
        "salon":           payload.get("salon", "Auditorio Nuevo").strip() or "Auditorio Nuevo",
        "activo":          True,
    }

    from datetime import datetime, timezone
    ponencia["creado_en"] = datetime.now(timezone.utc)

    col = _get_collection()
    result = col.insert_one(ponencia)
    ponencia["_id"] = str(result.inserted_id)
    ponencia["creado_en"] = ponencia["creado_en"].isoformat()

    response = {
        "ok":                  True,
        "message":             "Ponencia creada correctamente",
        "notification_status": "not_requested",
        "ponencia":            deepcopy(ponencia),
    }

    if notifier:
        try:
            notify_result = notifier({
                "titulo":         ponencia["titulo_ponencia"],
                "ponente_nombre": ponencia["nombre"],
                "fecha":          ponencia["fecha"],
                "hora":           ponencia["hora"],
            })
            response["notification_status"] = "sent" if notify_result.get("ok") else "degraded"
            if not notify_result.get("ok"):
                response["warning"] = notify_result.get("error", "La notificación no pudo procesarse")
        except Exception:
            response["notification_status"] = "degraded"
            response["warning"] = (
                "La ponencia fue creada, pero el servicio de notificaciones no está disponible"
            )

    return response
