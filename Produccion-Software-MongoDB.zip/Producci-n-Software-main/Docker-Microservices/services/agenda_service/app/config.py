import os


class Config:
    # Servicio de notificaciones
    NOTIFICATIONS_SERVICE_URL = os.getenv(
        "NOTIFICATIONS_SERVICE_URL", "http://notifications-service:5000"
    )
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "5"))

    # ── MongoDB ──────────────────────────────────────────
    # URI completa: mongodb://host:port/db
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017/coniiti_db")
    MONGO_DB = os.getenv("MONGO_DB", "coniiti_db")
