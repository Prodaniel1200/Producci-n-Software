import requests
from flask import Blueprint, current_app, jsonify, request
from .service import create_ponencia, get_agenda, get_ponente_by_id


agenda_bp = Blueprint("agenda_api", __name__)


@agenda_bp.get("/api/agenda")
def agenda():
    """Devuelve la agenda paginada con datos desde MongoDB."""
    return jsonify(
        get_agenda(
            page=request.args.get("page", 1, type=int),
            per_page=request.args.get("per_page", 5, type=int),
        )
    )


@agenda_bp.get("/api/ponentes/<ponente_id>")
def get_ponente(ponente_id: str):
    """Devuelve un ponente completo por su _id de MongoDB."""
    ponente = get_ponente_by_id(ponente_id)
    if not ponente:
        return jsonify({"ok": False, "error": "Ponente no encontrado"}), 404
    return jsonify(ponente)


@agenda_bp.post("/api/ponentes")
def create_ponente():
    """Crea un nuevo ponente y lo persiste en MongoDB."""
    payload = request.get_json(silent=True) or {}

    def notifier(notification_payload):
        response = requests.post(
            f"{current_app.config['NOTIFICATIONS_SERVICE_URL']}/api/notifications/ponencia-created",
            json=notification_payload,
            timeout=current_app.config["REQUEST_TIMEOUT"],
        )
        response.raise_for_status()
        return response.json()

    result = create_ponencia(payload, notifier=notifier)
    status = 201 if result.get("ok") else 400
    return jsonify(result), status
