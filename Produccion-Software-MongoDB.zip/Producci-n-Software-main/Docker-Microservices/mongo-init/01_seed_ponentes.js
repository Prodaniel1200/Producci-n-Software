// ============================================================
// MongoDB Seed Script – Colección: ponentes
// Base de datos: coniiti_db
// ============================================================
// Ejecutado automáticamente al iniciar el contenedor mongo
// (se monta en /docker-entrypoint-initdb.d/)
// ============================================================

db = db.getSiblingDB("coniiti_db");

// Limpiar colección si ya existe (útil para re-seeds en dev)
db.ponentes.drop();

db.ponentes.insertMany([
  {
    nombre: "Dra. Martinez",
    pais: "Mexico",
    // Ruta relativa al static/ del web_service (se usa en img src)
    bandera: "banderas/mexico.png",
    // URL pública de la bandera (emoji-flag CDN como fallback)
    bandera_url: "https://flagcdn.com/w40/mx.png",
    foto: null,           // URL/ruta a foto del ponente (null = sin foto aún)
    descripcion: "Especialista en innovación tecnológica y transformación digital. Doctora en Ciencias de la Computación por la UNAM.",
    titulo_ponencia: "Innovación tecnológica en la era de la IA",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "09:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 1",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Ing. Perez",
    pais: "Colombia",
    bandera: "banderas/colombia.png",
    bandera_url: "https://flagcdn.com/w40/co.png",
    foto: null,
    descripcion: "Ingeniero de sistemas con más de 15 años en desarrollo de software y arquitecturas cloud. Especialista en microservicios.",
    titulo_ponencia: "Arquitecturas modernas con microservicios",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "10:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 2",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Dr. Lopez",
    pais: "Argentina",
    bandera: "banderas/argentina.png",
    bandera_url: "https://flagcdn.com/w40/ar.png",
    foto: null,
    descripcion: "Investigador en inteligencia artificial y visión por computadora. Doctor en Ingeniería por la UBA.",
    titulo_ponencia: "Visión por computadora: del laboratorio a la industria",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "11:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 3",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Dr. Hans Muller",
    pais: "Alemania",
    bandera: "banderas/alemania.png",
    bandera_url: "https://flagcdn.com/w40/de.png",
    foto: null,
    descripcion: "Experto en ciberseguridad y sistemas embebidos. Investigador senior en el Instituto Fraunhofer de Alemania.",
    titulo_ponencia: "Seguridad en sistemas embebidos y IoT",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "12:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 4",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Dr. Jean Dupont",
    pais: "Francia",
    bandera: "banderas/francia.png",
    bandera_url: "https://flagcdn.com/w40/fr.png",
    foto: null,
    descripcion: "Matemático y científico de datos. Investigador en aprendizaje automático y estadística bayesiana por la École Polytechnique.",
    titulo_ponencia: "Estadística bayesiana aplicada al Machine Learning",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "13:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 5",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Ing. Carlos Silva",
    pais: "Brasil",
    bandera: "banderas/brasil.png",
    bandera_url: "https://flagcdn.com/w40/br.png",
    foto: null,
    descripcion: "Ingeniero electrónico especializado en robótica y automatización industrial. Consultor para empresas del sector automotriz.",
    titulo_ponencia: "Robótica colaborativa en la industria 4.0",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "14:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 6",
    activo: true,
    creado_en: new Date()
  },
  {
    nombre: "Dra. Sofia Rodriguez",
    pais: "Panama",
    bandera: "banderas/panama.png",
    bandera_url: "https://flagcdn.com/w40/pa.png",
    foto: null,
    descripcion: "Investigadora en biotecnología e informática médica. Doctora en Bioingeniería por la Universidad de Panamá.",
    titulo_ponencia: "Bioinformática y medicina de precisión",
    tipo: "Conferencia",
    fecha: "2026-05-10",
    hora: "15:00",
    modalidad: "Presencial",
    sede: "Claustro",
    salon: "Auditorio 7",
    activo: true,
    creado_en: new Date()
  }
]);

// Índices útiles para queries frecuentes
db.ponentes.createIndex({ pais: 1 });
db.ponentes.createIndex({ activo: 1 });
db.ponentes.createIndex({ fecha: 1, hora: 1 });

print("✅ Seed completado: " + db.ponentes.countDocuments() + " ponentes insertados en coniiti_db.ponentes");
