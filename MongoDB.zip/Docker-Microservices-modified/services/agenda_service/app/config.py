import os


class Config:
    NOTIFICATIONS_SERVICE_URL = os.getenv(
        "NOTIFICATIONS_SERVICE_URL", "http://notifications-service:5000"
    )
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "5"))
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017/agenda_db")
