from flask import Flask
from .config import Config
from .routes import agenda_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    app.register_blueprint(agenda_bp)

    # Initialize MongoDB connection (seeds data if collection is empty)
    import os
    os.environ.setdefault("MONGO_URI", app.config["MONGO_URI"])

    @app.get("/health")
    def health():
        try:
            from .db import get_db
            get_db().command("ping")
            mongo_status = "ok"
        except Exception as e:
            mongo_status = f"error: {e}"
        return {"status": "ok", "service": "agenda_service", "mongo": mongo_status}

    return app
