import os
from pymongo import MongoClient

_client = None
_db = None

PONENTES_SEED = [
    {"nombre": "Dra. Martinez", "pais": "Mexico", "bandera": "banderas/mexico.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "09:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 1"},
    {"nombre": "Ing. Perez", "pais": "Colombia", "bandera": "banderas/colombia.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "10:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 2"},
    {"nombre": "Dr. Lopez", "pais": "Argentina", "bandera": "banderas/argentina.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "11:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 3"},
    {"nombre": "Dr. Hans Muller", "pais": "Alemania", "bandera": "banderas/alemania.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "12:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 4"},
    {"nombre": "Dr. Jean Dupont", "pais": "Francia", "bandera": "banderas/francia.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "13:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 5"},
    {"nombre": "Ing. Carlos Silva", "pais": "Brasil", "bandera": "banderas/brasil.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "14:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 6"},
    {"nombre": "Dra. Sofia Rodriguez", "pais": "Panama", "bandera": "banderas/panama.png",
     "titulo": "Innovacion tecnologica", "tipo": "Conferencia", "fecha": "2026-05-10",
     "hora": "15:00", "modalidad": "Presencial", "sede": "Claustro", "salon": "Auditorio 7"},
]


def get_db():
    global _client, _db
    if _db is None:
        mongo_uri = os.getenv("MONGO_URI", "mongodb://mongo:27017/agenda_db")
        _client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
        db_name = mongo_uri.rsplit("/", 1)[-1].split("?")[0] or "agenda_db"
        _db = _client[db_name]
        _seed_if_empty(_db)
    return _db


def _seed_if_empty(db):
    if db.ponentes.count_documents({}) == 0:
        db.ponentes.insert_many(PONENTES_SEED)
