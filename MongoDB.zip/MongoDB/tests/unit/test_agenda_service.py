import pytest
import mongomock
from requests.exceptions import RequestException
from unittest.mock import patch

from tests.conftest import service_import_path


# ── Fixture: mock MongoDB so tests run without a real Mongo instance ──────────
@pytest.fixture(autouse=True)
def mock_mongo(monkeypatch):
    """Replace pymongo.MongoClient with mongomock for all agenda tests."""
    with patch("pymongo.MongoClient", mongomock.MongoClient):
        yield


@pytest.fixture
def agenda_service_module():
    with service_import_path("agenda_service"):
        import app.db as db_module
        # Reset singleton so each test gets a fresh in-memory DB
        db_module._client = None
        db_module._db = None
        from app import service as service_module
        yield service_module
        # Teardown: reset singleton after test
        db_module._client = None
        db_module._db = None


# ── Unit tests ────────────────────────────────────────────────────────────────

@pytest.mark.unit
def test_get_agenda_returns_paginated_data(agenda_service_module):
    result = agenda_service_module.get_agenda(page=1, per_page=3)
    assert result["page"] == 1
    assert result["total_pages"] >= 3
    assert len(result["ponentes"]) == 3
    assert len(result["eventos"]) == 3


@pytest.mark.unit
def test_create_ponencia_validates_required_fields(agenda_service_module):
    result = agenda_service_module.create_ponencia(
        {"nombre": "", "pais": "Colombia", "titulo": "X",
         "fecha": "2026-05-10", "hora": "10:00"}
    )
    assert result["ok"] is False
    assert "faltantes" in result["error"]


@pytest.mark.unit
def test_create_ponencia_succeeds_and_marks_notification_sent(agenda_service_module):
    result = agenda_service_module.create_ponencia(
        {"nombre": "Ana", "pais": "Colombia", "titulo": "IA Responsable",
         "fecha": "2026-05-10", "hora": "10:00"},
        notifier=lambda payload: {"ok": True, "message": payload["titulo"]},
    )
    assert result["ok"] is True
    assert result["notification_status"] == "sent"

    # Verify persisted in MongoDB
    from app.db import get_db
    assert get_db().ponentes.count_documents({"nombre": "Ana"}) == 1


@pytest.mark.unit
def test_create_ponencia_keeps_system_alive_when_notifications_fail(agenda_service_module):
    def failing_notifier(payload):
        raise RequestException("service down")

    result = agenda_service_module.create_ponencia(
        {"nombre": "Ana", "pais": "Colombia", "titulo": "IA Responsable",
         "fecha": "2026-05-10", "hora": "10:00"},
        notifier=failing_notifier,
    )
    assert result["ok"] is True
    assert result["notification_status"] == "degraded"
    assert "notificaciones" in result["warning"]


@pytest.mark.unit
def test_agenda_route_returns_json(agenda_client):
    response = agenda_client.get("/api/agenda?page=1&per_page=2")
    assert response.status_code == 200
    body = response.get_json()
    assert body["page"] == 1
    assert len(body["eventos"]) == 2


@pytest.mark.unit
def test_create_ponente_route_still_returns_201_when_notification_service_is_down(
    agenda_client, monkeypatch
):
    with service_import_path("agenda_service"):
        import app.routes as routes_module

        def boom(*args, **kwargs):
            raise RequestException("notifications unavailable")

        monkeypatch.setattr(routes_module.requests, "post", boom)
        response = agenda_client.post(
            "/api/ponentes",
            json={"nombre": "Ana", "pais": "Colombia", "titulo": "IA Responsable",
                  "fecha": "2026-05-10", "hora": "10:00"},
        )

    assert response.status_code == 201
    assert response.get_json()["notification_status"] == "degraded"


@pytest.mark.unit
def test_create_ponencia_persists_to_mongodb(agenda_service_module):
    """Verify data actually goes to MongoDB and GET reflects it."""
    before = agenda_service_module.get_agenda(per_page=100)
    total_before = before["total_pages"] * before["per_page"]

    agenda_service_module.create_ponencia(
        {"nombre": "Dr. Nuevo", "pais": "Mexico", "titulo": "Test Mongo",
         "fecha": "2026-06-01", "hora": "09:00"}
    )

    from app.db import get_db
    count = get_db().ponentes.count_documents({"nombre": "Dr. Nuevo"})
    assert count == 1
